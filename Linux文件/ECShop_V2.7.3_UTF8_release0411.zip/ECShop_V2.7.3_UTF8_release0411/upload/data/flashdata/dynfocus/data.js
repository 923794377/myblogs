imgUrl1="data/afficheimg/20081027angsif.jpg";
imgtext1="ECShop";
imgLink1=escape("http://www.ecshop.com");
imgUrl2="data/afficheimg/20081027wdwd.jpg";
imgtext2="WDWD";
imgLink2=escape("http://www.wdwd.com");
imgUrl3="data/afficheimg/20081027xuorxj.jpg";
imgtext3="ECShop";
imgLink3=escape("http://help.ecshop.com/index.php?doc-view-108.htm");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3;