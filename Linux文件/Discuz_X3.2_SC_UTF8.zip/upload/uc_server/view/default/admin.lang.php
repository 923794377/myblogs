<?php

$lang = array(
	'user_search' => '搜索用户',
	'user_name' => '用户名',
	'user_regdate' => '注册日期',
	'user_regip' => '注册IP',
	'user_before' => '之前',
	'user_after' => '之后',
	'user_search' => '搜 索',
	'user_add' => '添加用户',
	'user_password' => '密码',
	'user_addsubmit' => '添 加',
	'delete' => '删除',
	'email' => 'Email',
	'user_list' => '用户列表',
);